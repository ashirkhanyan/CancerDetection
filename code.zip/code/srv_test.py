import getpass
import os
import json

if getpass.getuser() == 'srv':
    fld = "/Users/srv/Documents/Cloud"
else:
    fld = "/Users/aleks"

DATA_FOLDER = fld + "/Georgia Institute of Technology/MVP - General/test_set/benign"

if __name__ == "__main__":
    for folder in os.listdir(DATA_FOLDER):
        folder_path = os.path.join(DATA_FOLDER, folder)
        if not os.path.isdir(folder_path):
            continue
        for file in os.listdir(folder_path):
            if file[-4:] == "json":
                with open(os.path.join(DATA_FOLDER, folder, file)) as json_file:
                    json_data = json.load(json_file)
                    # if len(json_data["shapes"]) != 1:
                    print(len(json_data["shapes"]))