
DATA_FOLDER = "/Users/srv/Documents/Cloud/Georgia Institute of Technology/MVP - General/Ultrasound-labeled"
TEST_FOLDER = "/Users/srv/Documents/Cloud/Georgia Institute of Technology/MVP - General/test_set"
PLOT_FOLDER = "/Users/srv/Documents/Cloud/Georgia Institute of Technology/MVP - General/plots"
BASE_FOLDER = "/Users/srv/Documents/Cloud/Georgia Institute of Technology/MVP - General/baseline"
